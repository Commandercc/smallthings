package com.ccc.getjsondemo;


import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.List;

public class UserAdapter extends ArrayAdapter<User> {
    private int resourceId;

    public UserAdapter(Context context, int resourceId, List<User> objects) {
        super(context, resourceId, objects);
        this.resourceId = resourceId;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        User user = getItem(position);
        View view;
        ViewHolder viewHolder;
        if (convertView == null) {
            view = LayoutInflater.from(getContext()).inflate(resourceId, parent, false);
            viewHolder = new ViewHolder();
            viewHolder.userid = (TextView) view.findViewById(R.id.tv_id);
            viewHolder.username = (TextView) view.findViewById(R.id.tv_username);
            viewHolder.userpassword = (TextView) view.findViewById(R.id.tv_password);
            view.setTag(viewHolder); //将viewHolder存储在view中
        } else {
            view = convertView;
            viewHolder = (ViewHolder) view.getTag();
        }
        viewHolder.userid.setText(String.valueOf(user.getId()));
        viewHolder.username.setText(user.getUsername());
        viewHolder.userpassword.setText(user.getPassword());
        return view;
    }

    static class ViewHolder {
        TextView userid;
        TextView username;
        TextView userpassword;
    }
}



