package com.ccc.getjsondemo.service;

import com.ccc.getjsondemo.User;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.GET;

public interface ApiSevice {
    @GET("test.json")
    public Call<List<User>> getData();
}
