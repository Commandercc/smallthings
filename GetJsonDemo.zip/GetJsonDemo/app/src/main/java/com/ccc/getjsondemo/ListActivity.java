package com.ccc.getjsondemo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ListView;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.util.List;

public class ListActivity extends AppCompatActivity {

    private List<User> userList;
    private ListView listView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_list);

        Intent intent = getIntent();
        //获取传递的 list对象
        userList = (List<User>) intent.getSerializableExtra("userdata");

        listView = findViewById(R.id.lv);
        UserAdapter adapter = new UserAdapter(this,R.layout.user,userList);
        listView.setAdapter(adapter);
    }


}
